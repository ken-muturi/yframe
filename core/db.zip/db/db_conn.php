<?php
/**
 * An agnostic database wrapper
 * @depends : PDO PECL extension (see http://php.net/manual/en/book.pdo.php)
 * @depends : PHP >= 5.2.9
 * @yours-truly : ndungi@gmail.com
 * @license : 
 * *********************************************************************
 *  Basically, you can do whatever you want, as long as you don’t say you 
 *  wrote the library or hold the developer liable for any damages using 
 *  it might cause.
 * *********************************************************************
 * */

class db_conn extends PDO
{
	public $pk = 'id';
    public $prepared_stmt = array();
    public $tables = array();
    public $prepared_queries = 0;
    public $unprepared_queries = 0;
    public $Qstats = array();
    public $have_errors = FALSE;
    public $table_aliases = array();
    public $dbname = '';
    
    public static $_db = array();

    /**
     * __construct function
     * @param string $user   
     * @param string $pass   
     * @param string $dbname 
     * @param string $dbhost 
     * @param string $dbtype 
     */
    public function __construct ($user, $pass, $dbname, $dbhost, $dbtype)
    {		
        $this->dbname = $dbname;
        try 
        {
            $conn = parent::__construct("{$dbtype}:host=" . $dbhost . ";dbname=" . $dbname , 
                                        $user, $pass, 
                                        array(  PDO::ATTR_PERSISTENT => true, 
                                                PDO::ATTR_ERRMODE => true, 
                                                PDO::ERRMODE_EXCEPTION => true
                                        )
                            );

            // call the prepare tables function
            // this get the fields of each table prepares the tables relationships
            $this->prepare_tables();

            return $this;            
        } 
        catch (PDOException $e) 
        {            
            echo($e->getMessage());            
        }
           
    }

    /**
     * instance - create a factory pattern instance connection to the db.
     * @param  string $conn 
     * @return resource   -  db connection instance or empty array
     */
    public static function instance($conn = 'default')
    {			
        static $_db = array();

        if (!isset($_db[$conn])) 
        {	
			if (!count($_db))
				$_db = array();
				
			$_db[$conn] = null;
		}
        
        //create a db connection instace from connection parameters
        if ($_db[$conn] == null) 
        {
			$conf = util::conf();
			$_db[$conn] = new self(
				$conf["db_{$conn}"]["username"],
				$conf["db_{$conn}"]["password"],
				$conf["db_{$conn}"]["name"],
				$conf["db_{$conn}"]["host"],
				$conf["db_{$conn}"]["type"]
			);
	
        }

        return $_db[$conn];        
    }

    /**
     * prepare_tables function - This get the fields of each table prepares the tables relationships
     */
    protected function prepare_tables()
    {
        //query all tables in this database
        $get_tables_sql = "SELECT table_name " . 
                    "FROM information_schema.tables " . 
                    "WHERE table_type = 'BASE TABLE' AND " . 
                    "table_schema = '{$this->dbname}'"
            ;

        $tables = $tbls = $this->query($get_tables_sql)->fetchAll();
        foreach ($tables as $table) 
        {
            $table = $table[0];

            /**-------------------------------------------------------
             * Columns data
             *
             * @todo 1. get this into its own function 
             *       2. query columns needed at once not in the loop             * 
             * -------------------------------------------------------
            */
            $desc_table_sql = "SELECT column_name as field ".
            "FROM information_schema.columns " .
            "WHERE table_name = '{$table}'";

            $columns = $this->query($desc_table_sql)->fetchAll(PDO::FETCH_ASSOC);

            isset($this->table_aliases[$table]) and ($table = $this->table_aliases[$table]);

            $this->tables[$table]['fields'] = array();
            foreach ($columns as $column) 
            {
                $this->tables[$table]['fields'][] = $column['field']; 
            }

            /**-------------------------------------------------------
             * Relationships
             * -------------------------------------------------------
            */
            $table_fk = preg_replace("/s$/", "", $table) . "_{$this->pk}";
            
            //define the possible relationships
            $this->tables[$table]['rships'] = array('has_one' => array(), 'has_many' => array(), 'many_to_many' => array());

            $table_fields = $this->tables[$table]['fields'] ;
            
            foreach ($tbls as $tbl) 
            {                    
                $tbl = $tbl[0]; 
                
                isset($this->table_aliases[$tbl]) and ($tbl = $this->table_aliases[$tbl]);
                
                //create a tables foreign key
                // by replacing last space with nothing then appending the primary key to the end
                $tbl_fk = preg_replace("/s$/", "", $tbl) . "_{$this->pk}";
                
                //get all table fields from the tables object
                $tbl_fields = $this->tables[$tbl]['fields'] ;

                //check for a substring of the foreign key is found among the inner table fields
                if (self::in_fields($table_fk, $tbl_fields)) 
                {    
                    //check for a many to many table
                    //else its a has many relationship
                    if (preg_match("/\_{$table}|{$table}\_/", $tbl)) 
                    {
                        $this->tables[$table]['rships']['many_to_many'][] = preg_replace("/\_{$table}|{$table}\_/", "", $tbl);                        
                    } 
                    else 
                    {                        
                        $this->tables[$table]['rships']['has_many'][] = $tbl;
                    }
                                        
                }
                
                //check for a substring of the foreign key is found among the table fields
                // to define a has one relationship
                if (self::in_fields($tbl_fk, $table_fields)) 
                {    
                    $this->tables[$table]['rships']['has_one'][] = $tbl; 
                } 
            }                      
        } 

    }

    /**
     * in_fields - Checks for the occurence of a substring in an array of fields
     * @param  [type] $fk     
     * @param  array  $fields 
     * @return boolean     
     */
    private function in_fields( $fk, array $fields)
    {
        foreach ($fields as $field) 
        {
            if (preg_match("/{$fk}$/i", $field))  
            {
                return true;
            }
        }        
    }
    
    public function __destruct()
    {
        if (DEVELOPMENT) 
        {			
			$query_log  = "<pre>";
			$query_log .= "<br/>Prepared Queries : " . $this->prepared_queries;
			$query_log .= "<br/>Unprepared Queries : " . $this->unprepared_queries;			
			$query_log .= "<br/>Total Queries : " . ($this->prepared_queries + $this->unprepared_queries);

			$query_log .= "<br/>=======================================<br/>";
			
			foreach ($this->Qstats as $key => $times) {
				$query_log .= " " . $this->prepared_stmt[$key]->queryString . " --> " .  $times . "<br/>";
			}
			$query_log .= "<br/></pre>";
        }
    }    
    
}

/**
 *  End of db_conn.php
 */